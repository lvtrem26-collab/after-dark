import { NextRequest, NextResponse } from "next/server";
import { characters } from "@/lib/characters";

export const runtime = "nodejs";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const characterId = String(body.characterId ?? "");
    const messages = Array.isArray(body.messages) ? body.messages : [];
    const character = characters.find((item) => item.id === characterId);

    if (!character) {
      return NextResponse.json({ error: "Personagem não encontrado." }, { status: 404 });
    }
    if (!messages.length) {
      return NextResponse.json({ error: "Envie uma mensagem para começar." }, { status: 400 });
    }

    const apiKey = process.env.OPENAI_API_KEY;
    if (!apiKey) {
      return NextResponse.json({
        error: "A IA ainda não foi conectada. Configure OPENAI_API_KEY no arquivo .env.local para ativar respostas reais."
      }, { status: 503 });
    }

    const safeMessages = messages.slice(-16).map((message: { role?: string; content?: string }) => ({
      role: message.role === "assistant" ? "assistant" : "user",
      content: String(message.content ?? "").slice(0, 4000)
    }));

    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
        messages: [
          {
            role: "system",
            content: `${character.personality}\nTodos os personagens são fictícios e adultos. Mantenha a conversa respeitosa, consensual e segura. Não produza conteúdo sexual envolvendo menores ou pessoas reais.`
          },
          ...safeMessages
        ],
        temperature: 0.85,
        max_tokens: 500
      })
    });

    const data = await response.json();
    if (!response.ok) {
      return NextResponse.json({ error: data?.error?.message || "Não foi possível obter resposta da IA." }, { status: response.status });
    }

    const reply = data?.choices?.[0]?.message?.content;
    return NextResponse.json({ reply: typeof reply === "string" ? reply : "Não consegui formular uma resposta agora." });
  } catch {
    return NextResponse.json({ error: "Ocorreu um erro ao processar a conversa." }, { status: 500 });
  }
}
