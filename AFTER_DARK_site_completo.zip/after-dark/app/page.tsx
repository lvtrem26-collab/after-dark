"use client";

import { useEffect, useMemo, useState } from "react";
import { Menu, X, Compass, Heart, MessageCircle, Settings, Search, ArrowRight, ArrowLeft, Send, Sparkles, Moon, ShieldCheck, MoreHorizontal } from "lucide-react";
import { characters, type Character } from "@/lib/characters";

type Message = { role: "user" | "assistant"; content: string; time: string };
type ChatStore = Record<string, Message[]>;

const starterMessages = (character: Character): Message[] => [
  { role: "assistant", content: character.greeting, time: "agora" }
];

export default function Home() {
  const [selected, setSelected] = useState<Character | null>(null);
  const [filter, setFilter] = useState("Todos");
  const [query, setQuery] = useState("");
  const [favorites, setFavorites] = useState<string[]>([]);
  const [chats, setChats] = useState<ChatStore>({});
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [notice, setNotice] = useState("");
  const [ageAccepted, setAgeAccepted] = useState(false);
  const [showFavorites, setShowFavorites] = useState(false);

  useEffect(() => {
    try {
      setFavorites(JSON.parse(localStorage.getItem("afterdark:favorites") || "[]"));
      setChats(JSON.parse(localStorage.getItem("afterdark:chats") || "{}"));
      setAgeAccepted(localStorage.getItem("afterdark:18plus") === "yes");
    } catch { /* ignore invalid local data */ }
  }, []);

  useEffect(() => {
    if (ageAccepted) localStorage.setItem("afterdark:18plus", "yes");
  }, [ageAccepted]);

  useEffect(() => {
    localStorage.setItem("afterdark:favorites", JSON.stringify(favorites));
  }, [favorites]);

  useEffect(() => {
    localStorage.setItem("afterdark:chats", JSON.stringify(chats));
  }, [chats]);

  const filtered = useMemo(() => characters.filter((character) => {
    const matchesFilter = filter === "Todos" || character.style === filter;
    const matchesQuery = `${character.name} ${character.role} ${character.description}`.toLowerCase().includes(query.toLowerCase());
    const matchesFavorite = !showFavorites || favorites.includes(character.id);
    return matchesFilter && matchesQuery && matchesFavorite;
  }), [filter, query, showFavorites, favorites]);

  function toggleFavorite(id: string) {
    setFavorites((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id]);
  }

  function openChat(character: Character) {
    setSelected(character);
    setMenuOpen(false);
    setChats((current) => current[character.id]?.length ? current : { ...current, [character.id]: starterMessages(character) });
  }

  async function sendMessage() {
    if (!selected || !input.trim() || busy) return;
    const text = input.trim();
    const current = chats[selected.id] ?? starterMessages(selected);
    const next = [...current, { role: "user" as const, content: text, time: "agora" }];
    setChats((all) => ({ ...all, [selected.id]: next }));
    setInput("");
    setBusy(true);
    setNotice("");
    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          characterId: selected.id,
          messages: next.map(({ role, content }) => ({ role, content }))
        })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Falha ao conversar.");
      setChats((all) => ({
        ...all,
        [selected.id]: [...(all[selected.id] ?? next), { role: "assistant", content: data.reply, time: "agora" }]
      }));
    } catch (error) {
      setNotice(error instanceof Error ? error.message : "Não foi possível conectar.");
    } finally {
      setBusy(false);
    }
  }

  if (!ageAccepted) {
    return (
      <main className="age-screen">
        <div className="age-card">
          <div className="brand"><span className="brand-mark">A</span><span>AFTER <b>DARK</b></span></div>
          <div className="eyebrow"><span className="live-dot" /> UM UNIVERSO DE CONVERSAS</div>
          <h1>Entre depois<br />do <i>anoitecer.</i></h1>
          <p>Uma experiência de personagens fictícios e conversas com inteligência artificial.</p>
          <div className="age-warning"><ShieldCheck size={18} /><span>Esta plataforma é destinada a maiores de 18 anos. Personagens são fictícios.</span></div>
          <button className="primary-btn wide" onClick={() => setAgeAccepted(true)}>Tenho 18 anos ou mais <ArrowRight size={16} /></button>
          <span className="age-foot">Ao continuar, você confirma ter idade legal para acessar esta experiência.</span>
        </div>
      </main>
    );
  }

  return (
    <div className="shell">
      <aside className={`sidebar ${menuOpen ? "show" : ""}`}>
        <div className="brand"><span className="brand-mark">A</span><span>AFTER <b>DARK</b></span><button className="close-menu" onClick={() => setMenuOpen(false)} aria-label="Fechar menu"><X size={18} /></button></div>
        <div className="side-label">EXPLORAR</div>
        <button className={`nav-item ${!showFavorites && !selected ? "selected" : ""}`} onClick={() => { setSelected(null); setShowFavorites(false); }}><Compass size={17} /> Descobrir</button>
        <button className={`nav-item ${showFavorites ? "selected" : ""}`} onClick={() => { setSelected(null); setShowFavorites(true); }}><Heart size={17} /> Favoritos <span className="muted">{favorites.length}</span></button>
        <button className={`nav-item ${selected ? "selected" : ""}`} onClick={() => setSelected(null)}><MessageCircle size={17} /> Conversas <span className="muted">{Object.values(chats).filter((items) => items.length > 1).length}</span></button>
        <div className="side-bottom"><div className="profile-dot">AD</div><div><b>Visitante</b><small>Experiência local</small></div><Settings size={15} className="muted" /></div>
      </aside>

      <main className="main">
        <header className="topbar">
          <button className="mobile-menu" onClick={() => setMenuOpen(true)} aria-label="Abrir menu"><Menu size={20} /></button>
          <div className="breadcrumb">AFTER DARK <span>/</span> {selected ? selected.name.toUpperCase() : showFavorites ? "FAVORITOS" : "DESCOBRIR"}</div>
          <div className="top-actions"><span className="online"><i className="status-dot" /> SISTEMA ONLINE</span><div className="avatar">AD</div></div>
        </header>

        {selected ? (
          <section className="chat-layout">
            <div className="chat-head">
              <button className="back-btn" onClick={() => setSelected(null)}><ArrowLeft size={16} /> VOLTAR</button>
              <div className="chat-person"><img src={selected.image} alt="" /><div><h2>{selected.name}</h2><p><i className="status-dot" /> {selected.role}</p></div></div>
              <div className="chat-tools"><button className="icon-btn" title="Detalhes"><MoreHorizontal size={17} /></button></div>
            </div>
            <div className="scene" style={{ backgroundImage: `linear-gradient(90deg,#0b0910cc,#0b091055),url("${selected.image}")` }}>
              <div className="scene-tag"><i className="live-dot" /> CENA DE CONVERSA</div>
              <div className="scene-copy"><span>AFTER DARK / CONEXÃO</span><h1>Uma conversa<br /><i>sem roteiro.</i></h1><p>{selected.description}</p></div>
            </div>
            <div className="messages" id="messages">
              {(chats[selected.id] ?? starterMessages(selected)).map((message, index) => (
                <div className={`message-row ${message.role === "user" ? "user" : ""}`} key={`${selected.id}-${index}`}>
                  <div className="message-avatar">{message.role === "user" ? "EU" : selected.name.slice(0, 1)}</div>
                  <div className="bubble"><small>{message.role === "user" ? "VOCÊ" : selected.name.toUpperCase()}</small><p>{message.content}</p></div>
                </div>
              ))}
              {busy && <div className="typing"> {selected.name} está pensando <span>•••</span></div>}
              <div />
            </div>
            {notice && <div className="notice">{notice}</div>}
            <form className="composer" onSubmit={(event) => { event.preventDefault(); void sendMessage(); }}>
              <input value={input} onChange={(event) => setInput(event.target.value)} placeholder={`Escreva para ${selected.name}...`} aria-label="Sua mensagem" />
              <button type="submit" disabled={!input.trim() || busy} aria-label="Enviar mensagem"><Send size={17} /></button>
            </form>
            <p className="chat-note">PERSONAGENS FICTÍCIOS • CONVERSAS GERADAS POR IA • SEJA RESPEITOSO</p>
          </section>
        ) : (
          <div className="explore">
            <section className="hero">
              <div className="hero-glow" />
              <div className="eyebrow"><span className="live-dot" /> UM UNIVERSO ALÉM DO COMUM</div>
              <h1>Your world.<br /><span>Your rules.</span></h1>
              <p>Conheça personagens, descubra novas histórias e deixe cada conversa seguir seu próprio caminho.</p>
              <button className="primary-btn" onClick={() => document.getElementById("catalog")?.scrollIntoView({ behavior: "smooth" })}>EXPLORAR PERSONAGENS <span><ArrowRight size={14} /></span></button>
              <div className="hero-foot"><span>HISTÓRIAS QUE GANHAM VIDA</span><i className="hero-line" /><Moon size={14} /></div>
            </section>

            <section className="catalog" id="catalog">
              <div className="section-heading"><div><div className="eyebrow">ENCONTRE SUA CONEXÃO</div><h2>{showFavorites ? "Seus " : "Explore os "}<span>{showFavorites ? "favoritos." : "personagens."}</span></h2></div><span className="count">{filtered.length.toString().padStart(2, "0")} PERSONAGENS</span></div>
              <div className="filters">
                <label className="search"><Search size={15} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Buscar personagens..." /></label>
                <div className="filter-tabs">
                  {["Todos", "Romance", "Amizade", "Aventura", "Mistério"].map((item) => <button key={item} className={filter === item ? "active" : ""} onClick={() => setFilter(item)}>{item}</button>)}
                </div>
              </div>
              <div className="character-grid">
                {filtered.map((character) => (
                  <article className="character-card" key={character.id} onClick={() => openChat(character)}>
                    <div className="card-image"><img src={character.image} alt={character.name} /><div className="image-shade" /><span className="style-tag">{character.style.toUpperCase()}</span><button className={`favorite ${favorites.includes(character.id) ? "on" : ""}`} onClick={(event) => { event.stopPropagation(); toggleFavorite(character.id); }} aria-label="Adicionar aos favoritos"><Heart size={15} fill={favorites.includes(character.id) ? "currentColor" : "none"} /></button></div>
                    <div className="card-info"><span className="card-kicker">PERSONAGEM ORIGINAL</span><h3>{character.name}</h3><p>{character.role}</p><div className="card-bottom"><span>INICIAR CONVERSA</span><ArrowRight className="arrow" size={17} /></div></div>
                  </article>
                ))}
              </div>
              {!filtered.length && <div className="empty">Nenhum personagem encontrado.</div>}
            </section>
            <footer><div className="brand"><span className="brand-mark">A</span><span>AFTER <b>DARK</b></span></div><span>UM UNIVERSO DE POSSIBILIDADES</span><span>© 2026 AFTER DARK</span></footer>
          </div>
        )}
      </main>
    </div>
  );
}
