import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "AFTER DARK — Your world, your characters",
  description: "Um universo de personagens e conversas com inteligência artificial.",
  themeColor: "#0b0910"
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="pt-BR">
      <body>{children}</body>
    </html>
  );
}
