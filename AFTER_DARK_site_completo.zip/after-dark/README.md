# AFTER DARK

Protótipo web responsivo em Next.js 15 + React 19 + TypeScript, mantendo a identidade visual preta e roxa enviada pelo usuário.

## O que funciona nesta versão
- Página inicial responsiva.
- Catálogo com quatro personagens fictícios adultos.
- Busca e filtros por estilo.
- Favoritos salvos no navegador.
- Conversas e histórico local salvos no navegador.
- Rota de backend para respostas reais via API da OpenAI.
- Aviso de idade 18+ na entrada.

## Requisitos
Node.js 20.9 ou superior.

## Executar localmente
1. Extraia o ZIP.
2. Abra a pasta `after-dark` no terminal.
3. Execute `npm install`.
4. Copie `.env.example` para `.env.local`.
5. Adicione sua chave em `OPENAI_API_KEY` no `.env.local`.
6. Execute `npm run dev`.
7. Acesse `http://localhost:3000`.

Sem chave de API, a interface abre e as conversas podem ser iniciadas, mas o servidor informa que a IA ainda não foi conectada.

## Segurança e limites
- Nunca coloque `OPENAI_API_KEY` em código do navegador.
- Não envie `.env.local` ao GitHub.
- O aviso 18+ é uma confirmação de entrada, não uma verificação de identidade/idade robusta.
- Favoritos e histórico são armazenados somente no navegador atual. Ainda não há login, banco de dados ou sincronização entre dispositivos.
- Configure moderação, limites de uso, política de privacidade e controles de segurança antes de disponibilizar publicamente.
- O uso da API pode gerar custos cobrados pelo provedor.

## Próximas etapas
Autenticação, banco de dados, memória persistente por personagem, moderação avançada, painel administrativo, testes, deploy e empacotamento Android (depois de validar a aplicação web).
